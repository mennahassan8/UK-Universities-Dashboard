﻿am5.ready(function () {
    let rawData = [];
    let cleanedData = [];
    let ieltsMode = "pie";
    let allChartInstances = {};
    const THEME = {
        bg: "#F5F7FA",
        card: "#FFFFFF",
        primary: "#1F3A5F",
        secondary: "#4F81BD",
        accent: "#F28C28",
        light: "#A3C1E5",
        text: "#2E2E2E"
    };

    function parsePercent(v) {
        if (v === undefined || v === null || v === "NA" || v === "" || v === "N/A") return null;
        const cleaned = v.toString().replace("%", "").trim();
        const num = Number(cleaned);
        return isNaN(num) ? null : num;
    }

    function toNumber(v) {
        if (v === undefined || v === null || v === "NA" || v === "" || v === "N/A") return null;
        const cleaned = v.toString().replace(/,/g, "").trim();
        const num = Number(cleaned);
        return isNaN(num) ? null : num;
    }

    function extractNumber(v) {
        if (!v || v === "NA" || v === "" || v === "N/A") return null;
        let nums = v.toString().match(/\d+/g);
        if (!nums) return null;
        if (nums.length === 2) return (Number(nums[0]) + Number(nums[1])) / 2;
        return Number(nums[0]);
    }

    function cleanData(data) {
        return data
            .filter(d => d.University_name && d.University_name.trim() !== "")
            .map(d => {
                d.International_Students = parsePercent(d.International_students);
                d.Student_Satisfaction = parsePercent(d.Student_satisfaction);
                d.UK_rank = toNumber(d.UK_rank);
                d.World_rank = toNumber(d.World_rank);
                d.CWUR_score = toNumber(d.CWUR_score);
                d.Minimum_IELTS_score = toNumber(d.Minimum_IELTS_score);
                d.UG_Fees = toNumber(d.UG_average_fees__in_pounds_);
                d.PG_Fees = toNumber(d.PG_average_fees__in_pounds_);
                d.Estimated_Living_Cost = toNumber(d.Estimated_cost_of_living_per_year__in_pounds_);
                d.Latitude = toNumber(d.Latitude);
                d.Longitude = toNumber(d.Longitude);
                d.Student_Enrollment = extractNumber(d.Student_enrollment);
                d.Academic_Staff = extractNumber(d.Academic_staff);
                d.Region = d.Region || "Unknown";
                d.Academic_Calendar_Type = d.Academic_Calender || "Unknown";
                d.Campus_Setting = d.Campus_setting || "Unknown";
                return d;
            });
    }

    function loadCSVData() {
        console.log("Loading CSV data...");
        const csvText = `University_name,Region,Founded_year,Motto,UK_rank,World_rank,CWUR_score,Minimum_IELTS_score,UG_average_fees_(in_pounds),PG_average_fees_(in_pounds),International_students,Student_satisfaction,Student_enrollment,Academic_staff,Control_type,Academic_Calender,Campus_setting,Estimated_cost_of_living_per_year_(in_pounds),Latitude,Longitude,Website
University of Cambridge,East of England,1209,"From here, light and sacred draughts",1,4,94.1,6.5,21750,23187,20.20%,85.50%,"20,000-24,999","over-5,000",Public,Trimesters,Urban,12000,52.2054,0.1132,www.cam.ac.uk
University of Oxford,South East England,1096,The Lord is my light,2,2,93.3,6.5,21770,19888,16.80%,86.50%,"25,000-29,999","over-5,000",Public,Trimesters,Urban,11500,51.7548,-1.2544,www.ox.ac.uk
University of St Andrews,Scotland,1413,Ever to excel,3,86,75.8,6.5,17040,15440,40.40%,87.90%,"10,000-14,999","1,000-1,499",Public,Semesters,Suburban,12000,56.3417,-2.7943,www.st-andrews.ac.uk
Imperial College London,London,1907,Knowledge is the adornment and safeguard of the Empire,4,8,86.6,6.5,23500,29900,41.40%,77.90%,"15,000-19,999","4,000-4,499",Public,Continuous,Urban,10700,51.4988,-0.1749,www.ic.ac.uk
Loughborough University,East Midlands,1966,"With Truth, Knowledge and Labour",5,404,72.8,5.5,16400,16400,22.00%,85.80%,"15,000-19,999","1,500-1,999",Public,Semesters,Suburban,9398,52.765,-1.2321,www.lboro.ac.uk`;

        const lines = csvText.trim().split('\n');
        const headers = lines[0].split(',').map(h => h.trim());

        rawData = lines.slice(1).map(line => {
            const values = [];
            let current = '';
            let inQuotes = false;

            for (let i = 0; i < line.length; i++) {
                const char = line[i];
                if (char === '"') {
                    inQuotes = !inQuotes;
                } else if (char === ',' && !inQuotes) {
                    values.push(current);
                    current = '';
                } else {
                    current += char;
                }
            }
            values.push(current);

            const obj = {};
            headers.forEach((header, index) => {
                obj[header] = (values[index] || "").trim();
            });
            return obj;
        });

        console.log("Raw data parsed:", rawData);
        cleanedData = cleanData(rawData);
        console.log("Cleaned data:", cleanedData);

        initFilters();
        updateDashboard(cleanedData);
        updateTables(cleanedData);
        updateKeyFindings(cleanedData);
    }

    function initFilters() {
        const regions = [...new Set(cleanedData.map(d => d.Region).filter(Boolean))].sort();
        const regionSelect = document.getElementById("regionFilter");
        regionSelect.innerHTML = '';

        regions.forEach(r => {
            let opt = document.createElement("option");
            opt.value = r;
            opt.text = r;
            opt.selected = true;
            regionSelect.appendChild(opt);
        });

        const feeFilter = document.getElementById("feeFilter");
        const feeValue = document.getElementById("feeValue");

        feeFilter.value = 50000;
        feeValue.textContent = "£50,000";

        feeFilter.addEventListener("input", function () {
            feeValue.textContent = "£" + parseInt(this.value).toLocaleString();
            applyFilters();
        });

        regionSelect.addEventListener("change", applyFilters);

        document.getElementById("toggleIELTS").addEventListener("click", () => {
            ieltsMode = ieltsMode === "pie" ? "bar" : "pie";
            document.getElementById("ieltsMode").textContent =
                ieltsMode === "pie" ? "Pie Chart" : "Bar Chart";
            applyFilters();
        });
    }

    function applyFilters() {
        const selectedRegions = [...document.getElementById("regionFilter").selectedOptions].map(o => o.value);
        const maxFee = parseInt(document.getElementById("feeFilter").value);

        const filtered = cleanedData.filter(d =>
            (selectedRegions.length === 0 || selectedRegions.includes(d.Region)) &&
            (d.UG_Fees <= maxFee || maxFee === 0 || d.UG_Fees === null)
        );

        console.log("Filtered data:", filtered);
        updateDashboard(filtered);
        updateTables(filtered);
        updateKeyFindings(filtered);
    }

    function updateDashboard(data) {
        renderKPIs(data);
        chart1(data);
        chart2(data);
        chart3(data);
        heatmap(data);
        mapChart(data);
        chart6(data);
    }

    function renderKPIs(data) {
        const kpis = document.getElementById("kpis");
        if (data.length === 0) {
            kpis.innerHTML = '<div class="col-12"><h4 class="text-center">No data available</h4></div>';
            return;
        }

        const topRanked = data.reduce((min, item) =>
            (item.UK_rank || 999) < (min.UK_rank || 999) ? item : min
        );

        kpis.innerHTML = `
        <div class="col-md-2">
            <div class="card">
                <div class="card-body text-center">
                    <h6 class="card-title">Total Universities</h6>
                    <h3 class="card-text">${data.length}</h3>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body text-center">
                    <h6 class="card-title">Avg International %</h6>
                    <h3 class="card-text">${avg(data, "International_Students")}%</h3>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body text-center">
                    <h6 class="card-title">Avg Satisfaction</h6>
                    <h3 class="card-text">${avg(data, "Student_Satisfaction")}%</h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h6 class="card-title">Avg UG Fees</h6>
                    <h3 class="card-text">£${avg(data, "UG_Fees", true)}</h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h6 class="card-title">Top Ranked</h6>
                    <h3 class="card-text" title="${topRanked.University_name}">${topRanked.University_name?.substring(0, 15)}${topRanked.University_name?.length > 15 ? '...' : ''}</h3>
                </div>
            </div>
        </div>
    `;
    }

    function avg(arr, field, formatNumber = false) {
        let v = arr.map(d => d[field]).filter(x => x !== null && !isNaN(x));
        if (v.length === 0) return formatNumber ? "0" : "0.0";
        const average = v.reduce((a, b) => a + b, 0) / v.length;
        if (formatNumber) {
            return Math.round(average).toLocaleString();
        }
        return average.toFixed(1);
    }

    function chart1(data) {
        if (allChartInstances.chart1) {
            allChartInstances.chart1.dispose();
        }

        const root = am5.Root.new("chart1");
        root.setThemes([am5themes_Animated.new(root)]);
        allChartInstances.chart1 = root;

        if (data.length === 0) {
            root.container.children.push(am5.Label.new(root, {
                text: "No data available",
                fontSize: 20,
                x: am5.percent(50),
                y: am5.percent(50),
                centerX: am5.percent(50),
                centerY: am5.percent(50)
            }));
            return;
        }

        const chart = root.container.children.push(
            am5xy.XYChart.new(root, {
                panX: true,
                panY: true,
                wheelX: "panX",
                wheelY: "zoomX",
                paddingLeft: 0,
                paddingRight: 20
            })
        );

        const xAxis = chart.xAxes.push(
            am5xy.CategoryAxis.new(root, {
                categoryField: "University_name",
                renderer: am5xy.AxisRendererX.new(root, {
                    minGridDistance: 50,
                    cellStartLocation: 0.1,
                    cellEndLocation: 0.9
                })
            })
        );

        xAxis.get("renderer").labels.template.setAll({
            rotation: -45,
            centerY: am5.p100,
            centerX: am5.p100,
            paddingTop: 5,
            fontSize: 12
        });

        const yAxis = chart.yAxes.push(
            am5xy.ValueAxis.new(root, {
                renderer: am5xy.AxisRendererY.new(root, {}),
                min: 0,
                max: 100
            })
        );

        const yAxis2 = chart.yAxes.push(
            am5xy.ValueAxis.new(root, {
                renderer: am5xy.AxisRendererY.new(root, {
                    opposite: true
                }),
                min: 0,
                max: 100
            })
        );

        const series1 = chart.series.push(
            am5xy.ColumnSeries.new(root, {
                name: "International Students",
                xAxis: xAxis,
                yAxis: yAxis,
                valueYField: "International_Students",
                categoryXField: "University_name",
                fill: am5.color(THEME.secondary),
                tooltip: am5.Tooltip.new(root, {
                    labelText: "{name}: {valueY}%"
                })
            })
        );

        const series2 = chart.series.push(
            am5xy.LineSeries.new(root, {
                name: "Student Satisfaction",
                xAxis: xAxis,
                yAxis: yAxis2,
                valueYField: "Student_Satisfaction",
                categoryXField: "University_name",
                stroke: am5.color(THEME.accent),
                tooltip: am5.Tooltip.new(root, {
                    labelText: "{name}: {valueY}%"
                })
            })
        );

        const chartData = data.map(d => ({
            University_name: d.University_name,
            International_Students: d.International_Students || 0,
            Student_Satisfaction: d.Student_Satisfaction || 0
        }));

        xAxis.data.setAll(chartData);
        series1.data.setAll(chartData);
        series2.data.setAll(chartData);

        chart.set("cursor", am5xy.XYCursor.new(root, {}));

        const legend = chart.children.push(
            am5.Legend.new(root, {
                centerX: am5.percent(50),
                x: am5.percent(50),
                y: am5.percent(100),
                centerY: am5.percent(100),
                layout: root.horizontalLayout,
                dy: 10
            })
        );
        legend.data.setAll([series1, series2]);

        series1.appear();
        series2.appear();
        chart.appear(1000, 100);
    }

    function chart2(data) {
        if (allChartInstances.chart2) {
            allChartInstances.chart2.dispose();
        }

        const root = am5.Root.new("chart2");
        root.setThemes([am5themes_Animated.new(root)]);
        allChartInstances.chart2 = root;

        if (data.length === 0) {
            root.container.children.push(am5.Label.new(root, {
                text: "No data available",
                fontSize: 20,
                x: am5.percent(50),
                y: am5.percent(50),
                centerX: am5.percent(50),
                centerY: am5.percent(50)
            }));
            return;
        }

        const chart = root.container.children.push(
            am5xy.XYChart.new(root, {
                panX: true,
                panY: true,
                wheelX: "panX",
                wheelY: "zoomX"
            })
        );

        const xAxis = chart.xAxes.push(
            am5xy.ValueAxis.new(root, {
                renderer: am5xy.AxisRendererX.new(root, {}),
                title: am5.Label.new(root, {
                    text: "UK Rank",
                    fontSize: 14
                })
            })
        );

        const yAxis = chart.yAxes.push(
            am5xy.ValueAxis.new(root, {
                renderer: am5xy.AxisRendererY.new(root, {}),
                title: am5.Label.new(root, {
                    text: "CWUR Score",
                    fontSize: 14
                })
            })
        );

        const series = chart.series.push(
            am5xy.LineSeries.new(root, {
                xAxis: xAxis,
                yAxis: yAxis,
                valueYField: "CWUR_score",
                valueXField: "UK_rank",
                stroke: am5.color(THEME.primary),
                tooltip: am5.Tooltip.new(root, {
                    labelText: "{University_name}\nUK Rank: {UK_rank}\nCWUR Score: {CWUR_score}"
                })
            })
        );

        series.bullets.push(function () {
            return am5.Bullet.new(root, {
                sprite: am5.Circle.new(root, {
                    radius: 6,
                    fill: am5.color(THEME.accent),
                    stroke: am5.color(THEME.primary),
                    strokeWidth: 2
                })
            });
        });

        series.strokes.template.setAll({
            strokeWidth: 3
        });

        const chartData = data.filter(d => d.UK_rank && d.CWUR_score).map(d => ({
            UK_rank: d.UK_rank,
            CWUR_score: d.CWUR_score,
            University_name: d.University_name
        }));

        series.data.setAll(chartData);
        chart.set("cursor", am5xy.XYCursor.new(root, {}));

        series.appear();
        chart.appear(1000, 100);
    }

    function chart3(data) {
        if (allChartInstances.chart3) {
            allChartInstances.chart3.dispose();
        }

        const root = am5.Root.new("chart3");
        root.setThemes([am5themes_Animated.new(root)]);
        allChartInstances.chart3 = root;

        if (data.length === 0) {
            root.container.children.push(am5.Label.new(root, {
                text: "No data available",
                fontSize: 20,
                x: am5.percent(50),
                y: am5.percent(50),
                centerX: am5.percent(50),
                centerY: am5.percent(50)
            }));
            return;
        }

        const chart = root.container.children.push(
            am5xy.XYChart.new(root, {
                panX: true,
                panY: true,
                wheelX: "panX",
                wheelY: "zoomX",
                paddingLeft: 0,
                paddingRight: 20
            })
        );

        const xAxis = chart.xAxes.push(
            am5xy.CategoryAxis.new(root, {
                categoryField: "University_name",
                renderer: am5xy.AxisRendererX.new(root, {
                    minGridDistance: 50,
                    cellStartLocation: 0.1,
                    cellEndLocation: 0.9
                })
            })
        );

        xAxis.get("renderer").labels.template.setAll({
            rotation: -45,
            centerY: am5.p100,
            centerX: am5.p100,
            paddingTop: 5,
            fontSize: 12
        });

        const yAxis = chart.yAxes.push(
            am5xy.ValueAxis.new(root, {
                renderer: am5xy.AxisRendererY.new(root, {}),
                title: am5.Label.new(root, {
                    text: "Fees (£)",
                    fontSize: 14
                })
            })
        );

        const series1 = chart.series.push(
            am5xy.ColumnSeries.new(root, {
                name: "UG Fees",
                xAxis: xAxis,
                yAxis: yAxis,
                valueYField: "UG_Fees",
                categoryXField: "University_name",
                fill: am5.color(THEME.primary),
                tooltip: am5.Tooltip.new(root, {
                    labelText: "UG Fees: £{valueY}"
                })
            })
        );

        const series2 = chart.series.push(
            am5xy.ColumnSeries.new(root, {
                name: "PG Fees",
                xAxis: xAxis,
                yAxis: yAxis,
                valueYField: "PG_Fees",
                categoryXField: "University_name",
                fill: am5.color(THEME.light),
                tooltip: am5.Tooltip.new(root, {
                    labelText: "PG Fees: £{valueY}"
                })
            })
        );

        const chartData = data.map(d => ({
            University_name: d.University_name,
            UG_Fees: d.UG_Fees || 0,
            PG_Fees: d.PG_Fees || 0
        }));

        xAxis.data.setAll(chartData);
        series1.data.setAll(chartData);
        series2.data.setAll(chartData);

        chart.set("cursor", am5xy.XYCursor.new(root, {}));

        const legend = chart.children.push(
            am5.Legend.new(root, {
                centerX: am5.percent(50),
                x: am5.percent(50),
                y: am5.percent(100),
                centerY: am5.percent(100),
                layout: root.horizontalLayout,
                dy: 10
            })
        );
        legend.data.setAll([series1, series2]);

        series1.appear();
        series2.appear();
        chart.appear(1000, 100);
    }

    function heatmap(data) {
        if (allChartInstances.heatmap) {
            allChartInstances.heatmap.dispose();
        }

        const root = am5.Root.new("heatmap");
        root.setThemes([am5themes_Animated.new(root)]);
        allChartInstances.heatmap = root;

        if (data.length === 0) {
            root.container.children.push(am5.Label.new(root, {
                text: "No data available",
                fontSize: 20,
                x: am5.percent(50),
                y: am5.percent(50),
                centerX: am5.percent(50),
                centerY: am5.percent(50)
            }));
            return;
        }

        const chart = root.container.children.push(
            am5heatmap.Heatmap.new(root, {
                paddingLeft: 60,
                paddingRight: 20,
                paddingTop: 20,
                paddingBottom: 20
            })
        );

        const yAxis = chart.yAxes.push(
            am5xy.CategoryAxis.new(root, {
                categoryField: "metric",
                renderer: am5xy.AxisRendererY.new(root, {}),
                tooltip: am5.Tooltip.new(root, {})
            })
        );

        const xAxis = chart.xAxes.push(
            am5xy.CategoryAxis.new(root, {
                categoryField: "University_name",
                renderer: am5xy.AxisRendererX.new(root, {
                    minGridDistance: 30
                })
            })
        );

        xAxis.get("renderer").labels.template.setAll({
            rotation: -45,
            centerY: am5.p100,
            centerX: am5.p100,
            paddingTop: 5,
            fontSize: 11
        });

        yAxis.get("renderer").labels.template.setAll({
            fontSize: 12
        });

        const series = chart.series.push(
            am5heatmap.HeatColumnSeries.new(root, {
                xAxis: xAxis,
                yAxis: yAxis,
                valueField: "value"
            })
        );

        const heatmapData = [];
        const metrics = [
            { field: "International_Students", name: "International Students" },
            { field: "Student_Satisfaction", name: "Student Satisfaction" },
            { field: "UG_Fees", name: "UG Fees" },
            { field: "PG_Fees", name: "PG Fees" }
        ];

        data.forEach(university => {
            metrics.forEach(metric => {
                const value = university[metric.field];
                if (value !== null && value !== undefined && !isNaN(value)) {
                    heatmapData.push({
                        University_name: university.University_name,
                        metric: metric.name,
                        value: value
                    });
                }
            });
        });

        xAxis.data.setAll(data.map(d => ({ University_name: d.University_name })));
        yAxis.data.setAll(metrics.map(m => ({ metric: m.name })));
        series.data.setAll(heatmapData);

        series.columns.template.setAll({
            strokeWidth: 1,
            stroke: am5.color(0xffffff),
            tooltipText: "{University_name}\n{metric}: {value}"
        });

        series.set("heatRules", [{
            target: series.columns.template,
            dataField: "value",
            min: am5.color(0xffffff),
            max: am5.color(THEME.primary),
            key: "fill"
        }]);

        chart.appear(1000, 100);
    }

    function mapChart(data) {
        try {
            if (allChartInstances.mapChart) {
                allChartInstances.mapChart.dispose();
            }

            const root = am5.Root.new("mapChart");
            root.setThemes([am5themes_Animated.new(root)]);
            allChartInstances.mapChart = root;

            if (data.length === 0) {
                root.container.children.push(am5.Label.new(root, {
                    text: "No data available",
                    fontSize: 20,
                    x: am5.percent(50),
                    y: am5.percent(50),
                    centerX: am5.percent(50),
                    centerY: am5.percent(50)
                }));
                return;
            }

            const chart = root.container.children.push(
                am5map.MapChart.new(root, {
                    panX: "rotateX",
                    panY: "rotateY",
                    projection: am5map.geoMercator(),
                    paddingLeft: 0,
                    paddingRight: 0
                })
            );

            const polygonSeries = chart.series.push(
                am5map.MapPolygonSeries.new(root, {
                    geoJSON: am5geodata_ukLow
                })
            );

            polygonSeries.mapPolygons.template.setAll({
                tooltipText: "{name}",
                interactive: true,
                fill: am5.color(THEME.light),
                stroke: am5.color(THEME.primary),
                strokeWidth: 0.5
            });

            polygonSeries.mapPolygons.template.states.create("hover", {
                fill: am5.color(THEME.secondary)
            });

            // Add point series for universities
            const pointSeries = chart.series.push(
                am5map.MapPointSeries.new(root, {})
            );

            pointSeries.bullets.push(function (root, series, dataItem) {
                const container = am5.Container.new(root, {});

                // Calculate bubble size based on living cost
                const livingCost = dataItem.dataContext.Estimated_Living_Cost || 0;
                const radius = Math.max(5, Math.min(15, livingCost / 5000));

                const circle = container.children.push(
                    am5.Circle.new(root, {
                        radius: radius,
                        fill: am5.color(THEME.accent),
                        stroke: am5.color(THEME.primary),
                        strokeWidth: 2,
                        tooltipText: `
                        [bold]{University_name}[/]
                        
                        Region: {Region}
                        Estimated Living Cost: [bold]£{Estimated_Living_Cost}[/]
                        Latitude: {Latitude}
                        Longitude: {Longitude}
                        
                        [italic]Click for more details[/]
                    `
                    })
                );

                // Add a label for the university (abbreviated)
                const label = container.children.push(
                    am5.Label.new(root, {
                        text: "{University_abbr}",
                        fontSize: 10,
                        fill: am5.color(0x000000),
                        centerY: am5.percent(0),
                        centerX: am5.percent(0),
                        populateText: true
                    })
                );

                // Add click event
                circle.events.on("click", function (ev) {
                    const uniData = dataItem.dataContext;
                    alert(
                        `University: ${uniData.University_name}\n` +
                        `Region: ${uniData.Region}\n` +
                        `Estimated Living Cost: £${uniData.Estimated_Living_Cost ? uniData.Estimated_Living_Cost.toLocaleString() : 'N/A'}\n` +
                        `Location: ${uniData.Latitude}, ${uniData.Longitude}\n` +
                        `UG Fees: £${uniData.UG_Fees ? uniData.UG_Fees.toLocaleString() : 'N/A'}\n` +
                        `International Students: ${uniData.International_Students ? uniData.International_Students.toFixed(1) + '%' : 'N/A'}`
                    );
                });

                return am5.Bullet.new(root, {
                    sprite: container
                });
            });

            // Filter universities with valid coordinates
            const universitiesWithCoords = data.filter(d => d.Latitude && d.Longitude);

            const pointData = universitiesWithCoords.map(d => ({
                latitude: d.Latitude,
                longitude: d.Longitude,
                University_name: d.University_name,
                University_abbr: getUniversityAbbreviation(d.University_name),
                Region: d.Region,
                Estimated_Living_Cost: d.Estimated_Living_Cost ? d.Estimated_Living_Cost.toLocaleString() : 'N/A',
                Latitude: d.Latitude.toFixed(4),
                Longitude: d.Longitude.toFixed(4),
                UG_Fees: d.UG_Fees,
                International_Students: d.International_Students
            }));

            pointSeries.data.setAll(pointData);

            // Add legend
            const legend = chart.children.push(
                am5.Legend.new(root, {
                    centerX: am5.percent(50),
                    x: am5.percent(50),
                    y: am5.percent(95),
                    centerY: am5.percent(95),
                    layout: root.horizontalLayout,
                    dy: 10
                })
            );

            // Add legend items
            const legendData = [
                { name: "University Location", fill: THEME.accent },
                { name: "Region Boundary", fill: THEME.light }
            ];
            legend.data.setAll(legendData);

            chart.appear(1000, 100);

            console.log("Map chart created with", universitiesWithCoords.length, "universities");

            // Helper function to get university abbreviation
            function getUniversityAbbreviation(name) {
                if (!name) return "";

                // Common abbreviations
                const commonAbbr = {
                    "University of Cambridge": "Cambridge",
                    "University of Oxford": "Oxford",
                    "University College London": "UCL",
                    "Imperial College London": "Imperial",
                    "London School of Economics": "LSE",
                    "University of Edinburgh": "Edinburgh",
                    "University of Manchester": "Manchester",
                    "University of Bristol": "Bristol",
                    "University of Warwick": "Warwick",
                    "University of Glasgow": "Glasgow"
                };

                // Check if it's a common university
                for (const [fullName, abbr] of Object.entries(commonAbbr)) {
                    if (name.includes(fullName) || fullName.includes(name)) {
                        return abbr;
                    }
                }

                // Otherwise, take first letters or first word
                const words = name.split(' ');
                if (words.length >= 3) {
                    // Take first letter of first three words
                    return words.slice(0, 3).map(w => w[0]).join('');
                } else if (words.length === 2) {
                    // Take first two letters of each word
                    return words.map(w => w.substring(0, 2)).join('');
                } else {
                    // Take first 4 letters
                    return name.substring(0, 4);
                }
            }

        } catch (error) {
            console.error("Error creating map chart:", error);
            // Show error message
            if (allChartInstances.mapChart) {
                const root = allChartInstances.mapChart;
                root.container.children.push(am5.Label.new(root, {
                    text: "Error loading map data",
                    fontSize: 16,
                    x: am5.percent(50),
                    y: am5.percent(50),
                    centerX: am5.percent(50),
                    centerY: am5.percent(50)
                }));
            }
        }
    }

    function chart6(data) {
        if (allChartInstances.chart6) {
            allChartInstances.chart6.dispose();
        }

        const root = am5.Root.new("chart6");
        root.setThemes([am5themes_Animated.new(root)]);
        allChartInstances.chart6 = root;

        if (data.length === 0) {
            root.container.children.push(am5.Label.new(root, {
                text: "No data available",
                fontSize: 20,
                x: am5.percent(50),
                y: am5.percent(50),
                centerX: am5.percent(50),
                centerY: am5.percent(50)
            }));
            return;
        }

        const ieltsData = data.filter(d => d.Minimum_IELTS_score !== null);
        if (ieltsData.length === 0) {
            root.container.children.push(am5.Label.new(root, {
                text: "No IELTS data available",
                fontSize: 20,
                x: am5.percent(50),
                y: am5.percent(50),
                centerX: am5.percent(50),
                centerY: am5.percent(50)
            }));
            return;
        }

        const scoreCounts = {};
        ieltsData.forEach(d => {
            const score = d.Minimum_IELTS_score;
            scoreCounts[score] = (scoreCounts[score] || 0) + 1;
        });

        const chartData = Object.keys(scoreCounts).map(score => ({
            score: `IELTS ${score}`,
            count: scoreCounts[score]
        })).sort((a, b) => a.score.localeCompare(b.score));

        if (ieltsMode === "pie") {
            const chart = root.container.children.push(
                am5percent.PieChart.new(root, {
                    innerRadius: am5.percent(50),
                    layout: root.verticalLayout
                })
            );

            const series = chart.series.push(
                am5percent.PieSeries.new(root, {
                    name: "IELTS Scores",
                    categoryField: "score",
                    valueField: "count"
                })
            );

            series.get("colors").set("colors", [
                am5.color(THEME.primary),
                am5.color(THEME.secondary),
                am5.color(THEME.accent),
                am5.color(THEME.light)
            ]);

            series.slices.template.setAll({
                tooltipText: "{category}: {value} universities"
            });

            series.data.setAll(chartData);

            const legend = chart.children.push(
                am5.Legend.new(root, {
                    centerX: am5.percent(50),
                    x: am5.percent(50),
                    y: am5.percent(95),
                    layout: root.horizontalLayout
                })
            );
            legend.data.setAll(series.dataItems);

            series.appear();
            chart.appear(1000, 100);
        } else {
            const chart = root.container.children.push(
                am5xy.XYChart.new(root, {
                    panX: true,
                    panY: true,
                    wheelX: "panX",
                    wheelY: "zoomX"
                })
            );

            const xAxis = chart.xAxes.push(
                am5xy.CategoryAxis.new(root, {
                    categoryField: "score",
                    renderer: am5xy.AxisRendererX.new(root, {})
                })
            );

            const yAxis = chart.yAxes.push(
                am5xy.ValueAxis.new(root, {
                    renderer: am5xy.AxisRendererY.new(root, {}),
                    title: am5.Label.new(root, {
                        text: "Number of Universities",
                        fontSize: 14
                    })
                })
            );

            const series = chart.series.push(
                am5xy.ColumnSeries.new(root, {
                    name: "IELTS Scores",
                    xAxis: xAxis,
                    yAxis: yAxis,
                    valueYField: "count",
                    categoryXField: "score",
                    fill: am5.color(THEME.primary),
                    stroke: am5.color(THEME.primary),
                    tooltip: am5.Tooltip.new(root, {
                        labelText: "{categoryX}: {valueY} universities"
                    })
                })
            );

            series.columns.template.setAll({
                width: am5.percent(70),
                strokeWidth: 0
            });

            series.data.setAll(chartData);

            chart.set("cursor", am5xy.XYCursor.new(root, {}));

            const legend = chart.children.push(
                am5.Legend.new(root, {
                    centerX: am5.percent(50),
                    x: am5.percent(50),
                    y: am5.percent(95)
                })
            );
            legend.data.setAll([series]);

            series.appear();
            chart.appear(1000, 100);
        }
    }

    function updateTables(data) {
        const table1Body = document.getElementById("table1-body");
        const table2Body = document.getElementById("table2-body");
        table1Body.innerHTML = '';
        table2Body.innerHTML = '';

        data.slice(0, 20).forEach(university => {
            const row1 = document.createElement('tr');
            row1.innerHTML = `
                <td>${university.University_name || 'N/A'}</td>
                <td>${university.Region || 'N/A'}</td>
                <td>${university.UK_rank || 'N/A'}</td>
                <td>${university.UG_Fees ? '£' + university.UG_Fees.toLocaleString() : 'N/A'}</td>
                <td>${university.PG_Fees ? '£' + university.PG_Fees.toLocaleString() : 'N/A'}</td>
                <td>${university.Student_Satisfaction ? university.Student_Satisfaction + '%' : 'N/A'}</td>
                <td>${university.International_Students ? university.International_Students + '%' : 'N/A'}</td>
            `;
            table1Body.appendChild(row1);

            const row2 = document.createElement('tr');
            row2.innerHTML = `
                <td>${university.University_name || 'N/A'}</td>
                <td>${university.Student_Enrollment ? university.Student_Enrollment.toLocaleString() : 'N/A'}</td>
                <td>${university.Academic_Staff ? university.Academic_Staff.toLocaleString() : 'N/A'}</td>
                <td>${university.Estimated_Living_Cost ? '£' + university.Estimated_Living_Cost.toLocaleString() : 'N/A'}</td>
            `;
            table2Body.appendChild(row2);
        });
    }

    function updateKeyFindings(data) {
        const keyFindingsBody = document.getElementById("key-findings-body");
        keyFindingsBody.innerHTML = '';

        if (data.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = `<td colspan="2">No data available</td>`;
            keyFindingsBody.appendChild(row);
            return;
        }

        const avgSatisfaction = avg(data, "Student_Satisfaction");
        const avgInternational = avg(data, "International_Students");
        const avgUGFees = avg(data, "UG_Fees", true);

        const mostExpensive = data.reduce((max, item) =>
            (item.UG_Fees || 0) > (max.UG_Fees || 0) ? item : max, data[0]
        );

        const highestSatisfaction = data.reduce((max, item) =>
            (item.Student_Satisfaction || 0) > (max.Student_Satisfaction || 0) ? item : max, data[0]
        );

        const highestInternational = data.reduce((max, item) =>
            (item.International_Students || 0) > (max.International_Students || 0) ? item : max, data[0]
        );

        const findings = [
            { question: "Average Student Satisfaction", answer: avgSatisfaction + "%" },
            { question: "Average International Students", answer: avgInternational + "%" },
            { question: "Average Undergraduate Fees", answer: "£" + avgUGFees },
            { question: "Most Expensive University (UG)", answer: mostExpensive.University_name + " (£" + (mostExpensive.UG_Fees?.toLocaleString() || 'N/A') + ")" },
            { question: "Highest Student Satisfaction", answer: highestSatisfaction.University_name + " (" + highestSatisfaction.Student_Satisfaction + "%)" },
            { question: "Highest International Student %", answer: highestInternational.University_name + " (" + highestInternational.International_Students + "%)" },
            { question: "Total Universities in Dataset", answer: data.length },
            { question: "Regions Represented", answer: [...new Set(data.map(d => d.Region).filter(Boolean))].length }
        ];

        findings.forEach(finding => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${finding.question}</td>
                <td>${finding.answer}</td>
            `;
            keyFindingsBody.appendChild(row);
        });
    }

    loadCSVData();
});